    (function () {
      'use strict';

      var RATIOS = [
        { id: '1:1', label: '1:1', w: 1, h: 1 },
        { id: '3:4', label: '3:4', w: 3, h: 4 },
        { id: '9:16', label: '9:16', w: 9, h: 16 },
        { id: '4:3', label: '4:3', w: 4, h: 3 },
        { id: '16:9', label: '16:9', w: 16, h: 9 },
        { id: 'free', label: '自由', w: 0, h: 0 }
      ];

      var SHAPES = [
        { id: 'rect', label: '直角' },
        { id: 'circle', label: '圆形' },
        { id: 'round', label: '圆角' }
      ];

      var GRIDS = [
        { id: '1', label: '单图', cols: 1, rows: 1 },
        { id: '3h', label: '横三', cols: 3, rows: 1 },
        { id: '3v', label: '竖三', cols: 1, rows: 3 },
        { id: '6a', label: '2×3', cols: 2, rows: 3 },
        { id: '6b', label: '3×2', cols: 3, rows: 2 },
        { id: '9', label: '九宫', cols: 3, rows: 3 }
      ];

      var GAPS = [
        { id: 0, label: '无缝' },
        { id: 8, label: '细缝' },
        { id: 16, label: '宽缝' }
      ];

      var PERM_TIP = '需要相册权限才能继续，请在系统设置中允许小红书访问相册后重试';

      var state = {
        mode: null,
        image: null,
        images: [],
        cropIndex: 0,
        scale: 1,
        offsetX: 0,
        offsetY: 0,
        minScale: 1,
        zoomExtra: 0,
        cropW: 0,
        cropH: 0,
        cropX: 0,
        cropY: 0,
        targetCropW: 0,
        targetCropH: 0,
        dragMode: 'pan',
        resizeHandle: null,
        viewportW: 0,
        viewportH: 0,
        ratioId: '1:1',
        shapeId: 'rect',
        radiusPct: 20,
        gridId: '1',
        gridLineColor: 'rgba(255,255,255,0.85)',
        stitchGap: 0,
        dragging: false,
        lastX: 0,
        lastY: 0,
        lastMoveT: 0,
        velX: 0,
        velY: 0,
        inertiaRaf: 0,
        pinchStartDist: 0,
        pinchStartScale: 1,
        results: [],
        saving: false,
        animating: false,
        flipX: 1,
        flipY: 1,
        rotation: 0,
        displayRotation: 0,
        displayFlipX: 1,
        displayScale: 1
      };

      var screens = {
        home: document.getElementById('screen-home'),
        edit: document.getElementById('screen-edit'),
        stitch: document.getElementById('screen-stitch'),
        result: document.getElementById('screen-result')
      };

      var pageTitle = document.getElementById('page-title');
      var subtitle = document.getElementById('subtitle');
      var pendingEntryMode = null;
      var fileInputMulti = document.getElementById('file-input-multi');
      var fileInputAdd = document.getElementById('file-input-add');
      var cropViewport = document.getElementById('crop-viewport');
      var cropCanvas = document.getElementById('crop-canvas');
      var cropCtx = cropCanvas.getContext('2d');
      var workCanvas = document.getElementById('work-canvas');
      var workCtx = workCanvas.getContext('2d');
      var zoomSlider = document.getElementById('zoom-slider');
      var radiusSlider = document.getElementById('radius-slider');
      var radiusLabel = document.getElementById('radius-label');
      var radiusBar = document.getElementById('radius-bar');
      var resultGrid = document.getElementById('result-grid');
      var resultHint = document.getElementById('result-hint');
      var ratioChips = document.getElementById('ratio-chips');
      var shapeChips = document.getElementById('shape-chips');
      var gridChips = document.getElementById('grid-chips');
      var gapChips = document.getElementById('gap-chips');
      var pickerRow = document.getElementById('picker-row');
      var stitchPreview = document.getElementById('stitch-preview');
      var btnSave = document.getElementById('btn-save');
      var btnStitchSave = document.getElementById('btn-stitch-save');
      var toastEl = document.getElementById('toast');
      var toastTimer = null;
      var loadingMask = document.getElementById('loading-mask');
      var loadingText = document.getElementById('loading-text');
      var btnGridColor = document.getElementById('btn-grid-color');
      var gridColorDot = document.getElementById('grid-color-dot');
      var gridColorPop = document.getElementById('grid-color-pop');

      var GRID_LINE_COLORS = [
        { id: 'white', label: '白', value: 'rgba(255,255,255,0.85)', swatch: '#ffffff' },
        { id: 'black', label: '黑', value: 'rgba(0,0,0,0.7)', swatch: '#1c1c1e' },
        { id: 'blue', label: '蓝', value: 'rgba(0,122,255,0.9)', swatch: '#007aff' },
        { id: 'yellow', label: '黄', value: 'rgba(255,204,0,0.95)', swatch: '#ffcc00' },
        { id: 'red', label: '红', value: 'rgba(255,59,48,0.9)', swatch: '#ff3b30' }
      ];

      function syncGridColorUI() {
        var current = GRID_LINE_COLORS.filter(function (c) {
          return c.value === state.gridLineColor;
        })[0] || GRID_LINE_COLORS[0];
        if (gridColorDot) gridColorDot.style.background = current.swatch;
        if (!gridColorPop) return;
        Array.prototype.forEach.call(gridColorPop.querySelectorAll('.grid-color-swatch'), function (el) {
          el.classList.toggle('active', el.getAttribute('data-value') === state.gridLineColor);
        });
      }

      function closeGridColorPop() {
        if (gridColorPop) gridColorPop.classList.remove('open');
      }

      function openGridColorPop() {
        if (!gridColorPop || !btnGridColor) return;
        if (gridColorPop.parentNode !== document.body) {
          document.body.appendChild(gridColorPop);
        }
        gridColorPop.classList.add('open');
        // 先显示再量尺寸，避免被 panel overflow 裁切
        var btnRect = btnGridColor.getBoundingClientRect();
        var popRect = gridColorPop.getBoundingClientRect();
        var left = btnRect.right - popRect.width;
        var top = btnRect.top - popRect.height - 10;
        if (left < 12) left = 12;
        if (top < 12) top = btnRect.bottom + 10;
        var maxLeft = window.innerWidth - popRect.width - 12;
        if (left > maxLeft) left = Math.max(12, maxLeft);
        gridColorPop.style.left = Math.round(left) + 'px';
        gridColorPop.style.top = Math.round(top) + 'px';
      }

      function toggleGridColorPop() {
        if (!gridColorPop) return;
        if (gridColorPop.classList.contains('open')) closeGridColorPop();
        else openGridColorPop();
      }

      function renderGridColorPop() {
        if (!gridColorPop) return;
        gridColorPop.innerHTML = '';
        GRID_LINE_COLORS.forEach(function (c) {
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'grid-color-swatch' + (c.value === state.gridLineColor ? ' active' : '');
          btn.title = c.label;
          btn.setAttribute('data-value', c.value);
          btn.style.background = c.swatch;
          btn.addEventListener('click', function (e) {
            e.stopPropagation();
            state.gridLineColor = c.value;
            syncGridColorUI();
            closeGridColorPop();
            drawCrop();
          });
          gridColorPop.appendChild(btn);
        });
        syncGridColorUI();
      }

      function showToast(message) {
        if (!toastEl || !message) return;
        toastEl.textContent = message;
        toastEl.classList.add('show');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
          toastEl.classList.remove('show');
        }, 2200);
      }

      function showLoading(text) {
        if (loadingText) loadingText.textContent = text || '处理中…';
        if (loadingMask) loadingMask.classList.add('show');
      }

      function hideLoading() {
        if (loadingMask) loadingMask.classList.remove('show');
      }

      function hasXhs() {
        return !!(window.xhs && window.xhs.miniTool);
      }

      function easeOutCubic(t) {
        return 1 - Math.pow(1 - t, 3);
      }

      function showScreen(name) {
        Object.keys(screens).forEach(function (k) {
          screens[k].classList.toggle('active', k === name);
        });

        if (name === 'home') {
          pageTitle.textContent = '轻映';
          subtitle.textContent = '';
          subtitle.classList.add('subtitle-hidden');
        } else if (name === 'edit') {
          pageTitle.textContent = '裁图';
          subtitle.textContent = state.ratioId === 'free'
            ? '拖动四角调整选区，拖动内部移动图片'
            : '双指缩放，拖动调整构图';
          subtitle.classList.remove('subtitle-hidden');
        } else if (name === 'stitch') {
          pageTitle.textContent = '拼图';
          subtitle.textContent = state.images.length < 2
            ? '已带入裁图图片，可继续添加至 2～9 张'
            : ('已选 ' + state.images.length + ' 张，长按可调顺序');
          subtitle.classList.remove('subtitle-hidden');
        } else {
          pageTitle.textContent = '处理结果';
          subtitle.textContent = state.results.length > 1 ? '按序号顺序保存' : '可保存到相册';
          subtitle.classList.remove('subtitle-hidden');
        }
      }

      function syncCropImage() {
        if (!state.images.length) {
          state.image = null;
          return;
        }
        if (state.cropIndex < 0 || state.cropIndex >= state.images.length) {
          state.cropIndex = 0;
        }
        state.image = state.images[state.cropIndex];
      }

      function switchMode(mode, force) {
        if (!state.images.length) return;
        var sameView = mode === state.mode && (
          (mode === 'crop' && screens.edit.classList.contains('active')) ||
          (mode === 'stitch' && screens.stitch.classList.contains('active'))
        );
        if (sameView && !force) return;

        state.mode = mode;
        if (mode === 'crop') {
          syncCropImage();
          showScreen('edit');
          renderCropChips();
          requestAnimationFrame(function () {
            resizeCropCanvas();
            drawCrop();
          });
        } else {
          // 裁图 ↔ 拼图共用当前已选图片；不足 2 张也可先进入，存相册时再校验
          showScreen('stitch');
          renderGapChips();
          renderStitchPreview();
        }
      }

      function getRatio() {
        var r = RATIOS.filter(function (x) { return x.id === state.ratioId; })[0];
        if (!r || r.id === 'free') {
          if (state.cropW > 0 && state.cropH > 0) return state.cropW / state.cropH;
          if (!state.image) return 1;
          return state.image.naturalWidth / state.image.naturalHeight;
        }
        return r.w / r.h;
      }

      function setCropRect(x, y, w, h) {
        var minSize = 64;
        w = Math.max(minSize, Math.min(w, state.viewportW));
        h = Math.max(minSize, Math.min(h, state.viewportH));
        x = Math.max(0, Math.min(x, state.viewportW - w));
        y = Math.max(0, Math.min(y, state.viewportH - h));
        state.cropX = x;
        state.cropY = y;
        state.cropW = w;
        state.cropH = h;
      }

      function setCenteredCrop(w, h) {
        w = Math.min(w, state.viewportW);
        h = Math.min(h, state.viewportH);
        setCropRect((state.viewportW - w) / 2, (state.viewportH - h) / 2, w, h);
      }

      function getGrid() {
        return GRIDS.filter(function (x) { return x.id === state.gridId; })[0] || GRIDS[0];
      }

      function isShapedExport() {
        return state.shapeId !== 'rect' && state.gridId === '1';
      }

      function syncRadiusBar() {
        if (!radiusBar) return;
        if (state.shapeId === 'round') radiusBar.classList.add('is-open');
        else radiusBar.classList.remove('is-open');
      }

      function gridIconSvg(cols, rows) {
        var x0 = 3;
        var y0 = 3;
        var x1 = 19;
        var y1 = 19;
        var lines = '';
        var i;
        for (i = 1; i < cols; i++) {
          var x = x0 + (x1 - x0) * i / cols;
          lines += '<line x1="' + x.toFixed(1) + '" y1="' + y0 + '" x2="' + x.toFixed(1) + '" y2="' + y1 + '"/>';
        }
        for (i = 1; i < rows; i++) {
          var y = y0 + (y1 - y0) * i / rows;
          lines += '<line x1="' + x0 + '" y1="' + y.toFixed(1) + '" x2="' + x1 + '" y2="' + y.toFixed(1) + '"/>';
        }
        return '<svg viewBox="0 0 22 22"><rect x="3" y="3" width="16" height="16" rx="2"/>' + lines + '</svg>';
      }

      var segMemory = {};

      function syncSegThumb(group, key, animate) {
        if (!group) return;
        var thumb = group.querySelector('.seg-thumb');
        if (!thumb) {
          thumb = document.createElement('div');
          thumb.className = 'seg-thumb';
          group.insertBefore(thumb, group.firstChild);
        }
        var active = group.querySelector('.chip.active');
        if (!active) {
          thumb.classList.remove('is-ready');
          return;
        }
        var left = active.offsetLeft;
        var width = active.offsetWidth;
        var prev = segMemory[key];

        if (animate && prev && (prev.left !== left || prev.width !== width)) {
          thumb.style.transition = 'none';
          thumb.style.width = prev.width + 'px';
          thumb.style.transform = 'translateX(' + prev.left + 'px)';
          thumb.classList.add('is-ready');
          // force layout
          void thumb.offsetWidth;
          thumb.style.transition = '';
          thumb.style.width = width + 'px';
          thumb.style.transform = 'translateX(' + left + 'px)';
        } else {
          thumb.style.transition = 'none';
          thumb.style.width = width + 'px';
          thumb.style.transform = 'translateX(' + left + 'px)';
          thumb.classList.add('is-ready');
          void thumb.offsetWidth;
          thumb.style.transition = '';
        }
        segMemory[key] = { left: left, width: width };
      }

      function renderCropChips(animateSeg) {
        var shouldAnimate = !!animateSeg;
        ratioChips.innerHTML = '';
        RATIOS.forEach(function (r) {
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'chip' + (r.id === state.ratioId ? ' active' : '');
          btn.textContent = r.label;
          if (state.shapeId === 'circle' && r.id !== '1:1') btn.disabled = true;
          btn.addEventListener('click', function () {
            if (btn.disabled) return;
            if (state.ratioId === r.id) return;
            state.ratioId = r.id;
            if (r.id === 'free' && state.cropW > 0) {
              var nw = Math.min(state.cropW, state.viewportW * 0.86);
              var nh = Math.min(state.cropH, state.viewportH * 0.86);
              setCenteredCrop(nw, nh);
              computeMinScale();
              clampOffset();
              renderCropChips(true);
              drawCrop();
              if (screens.edit.classList.contains('active')) {
                subtitle.textContent = '拖动四角调整选区，拖动内部移动图片';
              }
              return;
            }
            renderCropChips(true);
            animateCropFrame();
            if (screens.edit.classList.contains('active')) {
              subtitle.textContent = '双指缩放，拖动调整构图';
            }
          });
          ratioChips.appendChild(btn);
        });

        shapeChips.innerHTML = '';
        SHAPES.forEach(function (s) {
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'chip' + (s.id === state.shapeId ? ' active' : '');
          btn.textContent = s.label;
          if (s.id !== 'rect' && state.gridId !== '1') btn.disabled = true;
          btn.addEventListener('click', function () {
            if (btn.disabled) return;
            if (state.shapeId === s.id) return;
            state.shapeId = s.id;
            if (s.id === 'circle') {
              state.ratioId = '1:1';
              state.gridId = '1';
            }
            syncRadiusBar();
            renderCropChips(true);
            animateCropFrame();
          });
          shapeChips.appendChild(btn);
        });

        gridChips.innerHTML = '';
        GRIDS.forEach(function (g) {
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'chip chip-grid' + (g.id === state.gridId ? ' active' : '');
          btn.title = g.label;
          btn.innerHTML = gridIconSvg(g.cols, g.rows);
          if (state.shapeId !== 'rect' && g.id !== '1') btn.disabled = true;
          btn.addEventListener('click', function () {
            if (btn.disabled) return;
            if (state.gridId === g.id) return;
            state.gridId = g.id;
            if (g.id !== '1' && state.shapeId !== 'rect') {
              state.shapeId = 'rect';
              syncRadiusBar();
            }
            renderCropChips(true);
            drawCrop();
          });
          gridChips.appendChild(btn);
        });

        syncRadiusBar();

        requestAnimationFrame(function () {
          syncSegThumb(ratioChips, 'ratio', shouldAnimate);
          syncSegThumb(shapeChips, 'shape', shouldAnimate);
          syncSegThumb(gridChips, 'grid', shouldAnimate);
        });
      }

      function renderGapChips(animateSeg) {
        var shouldAnimate = !!animateSeg;
        gapChips.innerHTML = '';
        GAPS.forEach(function (g) {
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'chip' + (g.id === state.stitchGap ? ' active' : '');
          btn.textContent = g.label;
          btn.addEventListener('click', function () {
            if (state.stitchGap === g.id) return;
            state.stitchGap = g.id;
            renderGapChips(true);
            renderStitchPreview();
          });
          gapChips.appendChild(btn);
        });
        requestAnimationFrame(function () {
          syncSegThumb(gapChips, 'gap', shouldAnimate);
        });
      }

      var blobUrls = [];

      function revokeBlobUrls() {
        var i;
        for (i = 0; i < blobUrls.length; i++) {
          try { URL.revokeObjectURL(blobUrls[i]); } catch (err) { /* ignore */ }
        }
        blobUrls = [];
      }

      function resetImageState() {
        revokeBlobUrls();
        state.image = null;
        state.images = [];
        state.cropIndex = 0;
        state.mode = null;
        state.scale = 1;
        state.offsetX = 0;
        state.offsetY = 0;
        state.zoomExtra = 0;
        state.results = [];
        state.flipX = 1;
        state.flipY = 1;
        state.rotation = 0;
        state.displayRotation = 0;
        state.displayFlipX = 1;
        state.displayScale = 1;
        fileInputMulti.value = '';
        fileInputAdd.value = '';
        resultGrid.innerHTML = '';
        stitchPreview.innerHTML = '';
        pickerRow.innerHTML = '';
        zoomSlider.value = '0';
      }

      function goHome() {
        resetImageState();
        pendingEntryMode = null;
        showScreen('home');
      }

      function goUpload() {
        goHome();
      }

      function openEntryPicker(mode) {
        pendingEntryMode = mode;
        fileInputMulti.value = '';
        fileInputMulti.click();
      }

      var MAX_PICK = 9;

      function isProbablyVideo(file) {
        if (!file) return false;
        var type = (file.type || '').toLowerCase();
        if (type.indexOf('video/') === 0) return true;
        // application/octet-stream + 视频扩展名
        var name = (file.name || '').toLowerCase();
        if (/\.(mp4|mov|m4v|avi|mkv|webm|3gp|mpeg|mpg|m3u8)$/.test(name)) return true;
        return false;
      }

      function isClearlyImage(file) {
        if (!file || isProbablyVideo(file)) return false;
        var type = (file.type || '').toLowerCase();
        if (type.indexOf('image/') === 0) return true;
        var name = (file.name || '').toLowerCase();
        if (/\.(jpe?g|png|gif|webp|bmp|heic|heif)$/.test(name)) return true;
        return false;
      }

      // 只靠 type / name / size 同步判断，绝不读 File 内容。
      // 小红书/iOS 上哪怕 slice 读视频头，也可能触发整段导出，卡数秒。
      function classifyFileSync(file) {
        if (!file) return 'unknown';
        if (isProbablyVideo(file)) return 'video';
        if (isClearlyImage(file)) return 'image';
        var size = file.size || 0;
        // 无明确图片标识的大文件，按视频忽略
        if (size >= 6 * 1024 * 1024) return 'video';
        return 'unknown';
      }

      function loadImage(file) {
        return new Promise(function (resolve, reject) {
          // 双保险：进到这里的必须已是明确图片
          if (!isClearlyImage(file)) {
            reject(new Error('not-image'));
            return;
          }
          var url = URL.createObjectURL(file);
          blobUrls.push(url);
          var img = new Image();
          var settled = false;
          var timer = setTimeout(function () {
            if (settled) return;
            settled = true;
            img.onload = null;
            img.onerror = null;
            reject(new Error('timeout'));
          }, 2500);

          img.onload = function () {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            resolve(img);
          };
          img.onerror = function () {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            reject(new Error('load'));
          };
          img.src = url;
        });
      }

      function computeTargetCropSize() {
        if (state.ratioId === 'free' && state.cropW > 40 && state.cropH > 40) {
          state.targetCropW = Math.min(state.cropW, state.viewportW);
          state.targetCropH = Math.min(state.cropH, state.viewportH);
          return;
        }
        var ratio = getRatio();
        var maxW = state.viewportW * (state.ratioId === 'free' ? 0.86 : 1);
        var maxH = state.viewportH * (state.ratioId === 'free' ? 0.86 : 1);
        var w = maxW;
        var h = w / ratio;
        if (h > maxH) {
          h = maxH;
          w = h * ratio;
        }
        state.targetCropW = w;
        state.targetCropH = h;
      }

      function computeMinScale() {
        if (!state.image) return;
        var cw = state.cropW || state.targetCropW;
        var ch = state.cropH || state.targetCropH;
        if (!cw || !ch) {
          computeTargetCropSize();
          cw = state.targetCropW;
          ch = state.targetCropH;
        }
        var img = state.image;
        state.minScale = Math.max(cw / img.naturalWidth, ch / img.naturalHeight);
        state.scale = state.minScale * (1 + state.zoomExtra / 100);
      }

      function animateCropFrame() {
        if (!state.image) return;
        computeTargetCropSize();
        var fromX = state.cropX;
        var fromY = state.cropY;
        var fromW = state.cropW || state.targetCropW;
        var fromH = state.cropH || state.targetCropH;
        var toW = state.targetCropW;
        var toH = state.targetCropH;
        var toX = (state.viewportW - toW) / 2;
        var toY = (state.viewportH - toH) / 2;
        var start = performance.now();
        var duration = 260;
        function frame(now) {
          var t = Math.min(1, (now - start) / duration);
          var e = easeOutCubic(t);
          state.cropW = fromW + (toW - fromW) * e;
          state.cropH = fromH + (toH - fromH) * e;
          state.cropX = fromX + (toX - fromX) * e;
          state.cropY = fromY + (toY - fromY) * e;
          computeMinScale();
          if (state.scale < state.minScale) state.scale = state.minScale;
          clampOffset();
          drawCrop();
          if (t < 1) requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
      }

      function getCropRect() {
        return {
          left: state.cropX,
          top: state.cropY,
          width: state.cropW,
          height: state.cropH
        };
      }

      function clampOffset() {
        if (!state.image) return;
        var img = state.image;
        var dw = img.naturalWidth * state.scale;
        var dh = img.naturalHeight * state.scale;
        var dx = state.viewportW / 2 - dw / 2 + state.offsetX;
        var dy = state.viewportH / 2 - dh / 2 + state.offsetY;
        var c = getCropRect();
        if (dx > c.left) state.offsetX -= dx - c.left;
        if (dy > c.top) state.offsetY -= dy - c.top;
        if (dx + dw < c.left + c.width) state.offsetX += c.left + c.width - (dx + dw);
        if (dy + dh < c.top + c.height) state.offsetY += c.top + c.height - (dy + dh);
      }

      function roundRectPath(ctx, x, y, w, h, r) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
      }

      function drawCrop() {
        if (!state.image) return;
        var w = state.viewportW;
        var h = state.viewportH;
        cropCtx.clearRect(0, 0, w, h);
        cropCtx.fillStyle = '#f2f2f7';
        cropCtx.fillRect(0, 0, w, h);

        var img = state.image;
        var cx = w / 2;
        var cy = h / 2;
        var dw = img.naturalWidth * state.scale;
        var dh = img.naturalHeight * state.scale;

        cropCtx.save();
        cropCtx.translate(cx + state.offsetX, cy + state.offsetY);
        cropCtx.rotate(state.displayRotation);
        cropCtx.scale(state.displayFlipX, 1);
        cropCtx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
        cropCtx.restore();

        var c = getCropRect();
        var grid = getGrid();

        // 外层蒙版：浅灰遮罩，再在选区内重绘原图
        cropCtx.fillStyle = 'rgba(242, 242, 247, 0.72)';
        cropCtx.fillRect(0, 0, w, h);

        cropCtx.save();
        cropCtx.beginPath();
        if (state.shapeId === 'circle') {
          cropCtx.arc(
            c.left + c.width / 2,
            c.top + c.height / 2,
            Math.min(c.width, c.height) / 2,
            0,
            Math.PI * 2
          );
        } else if (state.shapeId === 'round') {
          var rr = Math.min(c.width, c.height) * (state.radiusPct / 100);
          roundRectPath(cropCtx, c.left, c.top, c.width, c.height, rr);
        } else {
          cropCtx.rect(c.left, c.top, c.width, c.height);
        }
        cropCtx.clip();
        cropCtx.translate(cx + state.offsetX, cy + state.offsetY);
        cropCtx.rotate(state.displayRotation);
        cropCtx.scale(state.displayFlipX, 1);
        cropCtx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
        cropCtx.restore();

        var lineColor = state.gridLineColor || 'rgba(255,255,255,0.85)';
        cropCtx.strokeStyle = lineColor;
        cropCtx.lineWidth = 2;
        cropCtx.shadowColor = 'rgba(0, 0, 0, 0.18)';
        cropCtx.shadowBlur = 2;
        if (state.shapeId === 'circle') {
          cropCtx.beginPath();
          cropCtx.arc(c.left + c.width / 2, c.top + c.height / 2, Math.min(c.width, c.height) / 2 - 0.75, 0, Math.PI * 2);
          cropCtx.stroke();
        } else if (state.shapeId === 'round') {
          var rStroke = Math.min(c.width, c.height) * (state.radiusPct / 100);
          roundRectPath(cropCtx, c.left + 0.75, c.top + 0.75, c.width - 1.5, c.height - 1.5, rStroke);
          cropCtx.stroke();
        } else {
          cropCtx.strokeRect(c.left + 0.75, c.top + 0.75, c.width - 1.5, c.height - 1.5);
        }
        cropCtx.shadowColor = 'transparent';
        cropCtx.shadowBlur = 0;

        if (grid.cols * grid.rows > 1 && state.shapeId === 'rect') {
          cropCtx.strokeStyle = lineColor;
          cropCtx.lineWidth = 1.25;
          var cellW = c.width / grid.cols;
          var cellH = c.height / grid.rows;
          var i;
          for (i = 1; i < grid.cols; i++) {
            cropCtx.beginPath();
            cropCtx.moveTo(c.left + cellW * i, c.top);
            cropCtx.lineTo(c.left + cellW * i, c.top + c.height);
            cropCtx.stroke();
          }
          for (i = 1; i < grid.rows; i++) {
            cropCtx.beginPath();
            cropCtx.moveTo(c.left, c.top + cellH * i);
            cropCtx.lineTo(c.left + c.width, c.top + cellH * i);
            cropCtx.stroke();
          }
        }

        // 自由比例：四角把手，提示可拖拽调整
        if (state.ratioId === 'free' && state.shapeId === 'rect') {
          var hs = 7;
          var corners = [
            [c.left, c.top],
            [c.left + c.width, c.top],
            [c.left, c.top + c.height],
            [c.left + c.width, c.top + c.height]
          ];
          cropCtx.fillStyle = lineColor;
          corners.forEach(function (p) {
            cropCtx.fillRect(p[0] - hs / 2, p[1] - hs / 2, hs, hs);
          });
        }
      }

      function resizeCropCanvas() {
        if (!screens.edit.classList.contains('active')) return;
        if (!syncCropCanvasSize()) return;
        computeTargetCropSize();
        if (state.ratioId === 'free' && state.cropW > 40 && state.cropH > 40) {
          setCropRect(state.cropX, state.cropY, state.cropW, state.cropH);
        } else {
          setCenteredCrop(state.targetCropW, state.targetCropH);
        }
        computeMinScale();
        if (state.scale < state.minScale) state.scale = state.minScale;
        clampOffset();
        drawCrop();
      }

      function syncCropCanvasSize() {
        var rect = cropViewport.getBoundingClientRect();
        if (!rect.width) return false;
        var dpr = window.devicePixelRatio || 1;
        state.viewportW = rect.width;
        state.viewportH = rect.height;
        cropCanvas.width = Math.round(rect.width * dpr);
        cropCanvas.height = Math.round(rect.height * dpr);
        cropCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
        return true;
      }

      function getCropSourceRect() {
        var img = state.image;
        var dw = img.naturalWidth * state.scale;
        var dh = img.naturalHeight * state.scale;
        var dx = state.viewportW / 2 - dw / 2 + state.offsetX;
        var dy = state.viewportH / 2 - dh / 2 + state.offsetY;
        var c = getCropRect();
        var sx = (c.left - dx) / dw * img.naturalWidth;
        var sy = (c.top - dy) / dh * img.naturalHeight;
        var sw = c.width / dw * img.naturalWidth;
        var sh = c.height / dh * img.naturalHeight;
        sx = Math.max(0, sx);
        sy = Math.max(0, sy);
        sw = Math.min(sw, img.naturalWidth - sx);
        sh = Math.min(sh, img.naturalHeight - sy);
        return { sx: sx, sy: sy, sw: sw, sh: sh };
      }

      function ratioClass() {
        if (state.shapeId === 'circle') return 'circle';
        if (state.ratioId === '3:4') return 'ratio-34';
        if (state.ratioId === '9:16') return 'ratio-916';
        if (state.ratioId === '4:3') return 'ratio-43';
        if (state.ratioId === '16:9') return 'ratio-169';
        if (state.ratioId === 'free') return 'ratio-auto';
        return '';
      }

      function applyShapeMask(ctx, w, h) {
        if (state.shapeId === 'circle') {
          ctx.globalCompositeOperation = 'destination-in';
          ctx.beginPath();
          ctx.arc(w / 2, h / 2, Math.min(w, h) / 2, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalCompositeOperation = 'source-over';
        } else if (state.shapeId === 'round') {
          var r = Math.min(w, h) * (state.radiusPct / 100);
          ctx.globalCompositeOperation = 'destination-in';
          roundRectPath(ctx, 0, 0, w, h, r);
          ctx.fill();
          ctx.globalCompositeOperation = 'source-over';
        }
      }

      function processCrop() {
        if (!state.image || Math.abs(state.displayRotation) > 0.01) return;
        var src = getCropSourceRect();
        var grid = getGrid();
        var fullW = Math.max(1, Math.floor(src.sw));
        var fullH = Math.max(1, Math.floor(src.sh));
        var maxSide = 1440;
        var scale = Math.min(1, maxSide / Math.max(fullW, fullH));
        var outW = Math.max(1, Math.round(fullW * scale));
        var outH = Math.max(1, Math.round(fullH * scale));

        workCanvas.width = outW;
        workCanvas.height = outH;
        workCtx.clearRect(0, 0, outW, outH);
        workCtx.drawImage(state.image, src.sx, src.sy, src.sw, src.sh, 0, 0, outW, outH);

        if (grid.cols === 1 && grid.rows === 1) {
          if (isShapedExport()) applyShapeMask(workCtx, outW, outH);
          var mime = isShapedExport() ? 'image/png' : 'image/jpeg';
          state.results = [{ dataUrl: workCanvas.toDataURL(mime, 0.92), num: null }];
          renderResults();
          return;
        }

        var cellW = Math.floor(outW / grid.cols);
        var cellH = Math.floor(outH / grid.rows);
        var items = [];
        var row;
        var col;
        for (row = 0; row < grid.rows; row++) {
          for (col = 0; col < grid.cols; col++) {
            var tile = document.createElement('canvas');
            tile.width = cellW;
            tile.height = cellH;
            tile.getContext('2d').drawImage(
              workCanvas,
              col * cellW, row * cellH, cellW, cellH,
              0, 0, cellW, cellH
            );
            items.push({
              dataUrl: tile.toDataURL('image/jpeg', 0.92),
              num: row * grid.cols + col + 1
            });
          }
        }
        state.results = items;
        renderResults();
      }

      function renderStitchPreview() {
        stitchPreview.innerHTML = '';
        var stack = document.createElement('div');
        stack.className = 'stitch-stack';
        state.images.forEach(function (img, i) {
          var el = document.createElement('img');
          el.src = img.src;
          el.alt = '';
          el.draggable = false;
          if (i < state.images.length - 1 && state.stitchGap > 0) {
            el.style.marginBottom = state.stitchGap + 'px';
          }
          stack.appendChild(el);
        });
        stitchPreview.appendChild(stack);
        renderPicker();
      }

      function renderPicker() {
        pickerRow.innerHTML = '';
        state.images.forEach(function (img, index) {
          var wrap = document.createElement('div');
          wrap.className = 'thumb-wrap';
          wrap.setAttribute('data-index', String(index));

          var t = document.createElement('img');
          t.className = 'thumb';
          t.src = img.src;
          t.alt = '';
          t.draggable = false;
          wrap.appendChild(t);

          var close = document.createElement('button');
          close.type = 'button';
          close.className = 'thumb-close';
          close.textContent = '×';
          close.addEventListener('touchstart', function (e) {
            e.stopPropagation();
            if (dragState.timer) {
              clearTimeout(dragState.timer);
              dragState.timer = null;
            }
          }, { passive: true });
          close.addEventListener('mousedown', function (e) {
            e.stopPropagation();
            if (dragState.timer) {
              clearTimeout(dragState.timer);
              dragState.timer = null;
            }
          });
          close.addEventListener('click', function (e) {
            e.stopPropagation();
            e.preventDefault();
            endDrag();
            var live = Number(wrap.getAttribute('data-index'));
            removeImageAt(isNaN(live) ? index : live);
          });
          wrap.appendChild(close);

          bindThumbReorder(wrap, index);
          pickerRow.appendChild(wrap);
        });

        if (state.images.length < 9) {
          var add = document.createElement('button');
          add.type = 'button';
          add.className = 'thumb-add';
          add.textContent = '+';
          add.addEventListener('click', function () {
            fileInputAdd.click();
          });
          pickerRow.appendChild(add);
        }
      }

      var dragState = {
        active: false,
        from: -1,
        current: -1,
        startX: 0,
        startY: 0,
        offsetX: 0,
        offsetY: 0,
        timer: null,
        floatEl: null,
        listening: false,
        raf: 0,
        pendingX: 0,
        pendingY: 0
      };

      function getThumbWraps() {
        return Array.prototype.slice.call(pickerRow.querySelectorAll('.thumb-wrap'));
      }

      function syncThumbIndexes() {
        getThumbWraps().forEach(function (el, i) {
          el.setAttribute('data-index', String(i));
        });
      }

      function reorderImagesLive(from, to) {
        if (from === to || from < 0 || to < 0) return;
        var wraps = getThumbWraps();
        if (!wraps[from] || !wraps[to]) return;

        var moving = wraps[from];
        var target = wraps[to];
        var prev = [];
        var i;
        for (i = 0; i < wraps.length; i++) {
          prev.push({ el: wraps[i], rect: wraps[i].getBoundingClientRect() });
        }

        var cropImg = state.images[state.cropIndex];
        var item = state.images.splice(from, 1)[0];
        state.images.splice(to, 0, item);
        if (cropImg) {
          var ci = state.images.indexOf(cropImg);
          state.cropIndex = ci >= 0 ? ci : 0;
        }

        if (from < to) {
          pickerRow.insertBefore(moving, target.nextSibling);
        } else {
          pickerRow.insertBefore(moving, target);
        }

        syncThumbIndexes();

        // FLIP：只让位其他缩略图，不重建 DOM、不刷新长图预览
        for (i = 0; i < prev.length; i++) {
          var entry = prev[i];
          if (entry.el === moving) continue;
          var now = entry.el.getBoundingClientRect();
          var dx = entry.rect.left - now.left;
          var dy = entry.rect.top - now.top;
          if (dx === 0 && dy === 0) continue;
          entry.el.style.transition = 'none';
          entry.el.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
        }
        // force layout once
        pickerRow.offsetHeight;
        for (i = 0; i < prev.length; i++) {
          if (prev[i].el === moving) continue;
          prev[i].el.style.transition = 'transform 0.18s ease';
          prev[i].el.style.transform = '';
        }

        dragState.current = to;
        dragState.from = to;
      }

      function hitThumbIndex(clientX) {
        var wraps = getThumbWraps();
        if (!wraps.length) return -1;
        var cur = dragState.current;
        if (cur < 0 || cur >= wraps.length) cur = 0;

        // 滞回：只有越过相邻项中心才换位，避免在边界来回抖动
        if (cur < wraps.length - 1) {
          var next = wraps[cur + 1].getBoundingClientRect();
          if (clientX > next.left + next.width * 0.55) {
            var to = cur + 1;
            while (to < wraps.length - 1) {
              var further = wraps[to + 1].getBoundingClientRect();
              if (clientX > further.left + further.width * 0.55) to += 1;
              else break;
            }
            return to;
          }
        }
        if (cur > 0) {
          var prev = wraps[cur - 1].getBoundingClientRect();
          if (clientX < prev.left + prev.width * 0.45) {
            var toL = cur - 1;
            while (toL > 0) {
              var furtherL = wraps[toL - 1].getBoundingClientRect();
              if (clientX < furtherL.left + furtherL.width * 0.45) toL -= 1;
              else break;
            }
            return toL;
          }
        }
        return cur;
      }

      function onDragMove(clientX, clientY) {
        if (!dragState.active) return;
        if (dragState.floatEl) {
          dragState.floatEl.style.left = (clientX - dragState.offsetX) + 'px';
          dragState.floatEl.style.top = (clientY - dragState.offsetY) + 'px';
        }
        dragState.pendingX = clientX;
        dragState.pendingY = clientY;
        if (dragState.raf) return;
        dragState.raf = requestAnimationFrame(function () {
          dragState.raf = 0;
          if (!dragState.active) return;
          var to = hitThumbIndex(dragState.pendingX);
          if (to >= 0 && to !== dragState.current) {
            reorderImagesLive(dragState.current, to);
          }
        });
      }

      function endDrag() {
        if (dragState.timer) {
          clearTimeout(dragState.timer);
          dragState.timer = null;
        }
        if (dragState.raf) {
          cancelAnimationFrame(dragState.raf);
          dragState.raf = 0;
        }
        if (!dragState.active && !dragState.listening) return;
        dragState.active = false;
        dragState.listening = false;
        window.removeEventListener('touchmove', onWinTouchMove, true);
        window.removeEventListener('touchend', onWinTouchEnd, true);
        window.removeEventListener('touchcancel', onWinTouchEnd, true);
        window.removeEventListener('mousemove', onWinMouseMove, true);
        window.removeEventListener('mouseup', onWinMouseUp, true);
        if (dragState.floatEl) {
          if (dragState.floatEl.parentNode) dragState.floatEl.parentNode.removeChild(dragState.floatEl);
          dragState.floatEl = null;
        }
        getThumbWraps().forEach(function (el) {
          el.classList.remove('is-placeholder');
          el.style.transition = '';
          el.style.transform = '';
        });
        renderStitchPreview();
        subtitle.textContent = '已选 ' + state.images.length + ' 张，长按可调顺序';
      }

      function onWinTouchMove(e) {
        if (!dragState.active) return;
        if (e.touches.length !== 1) return;
        e.preventDefault();
        onDragMove(e.touches[0].clientX, e.touches[0].clientY);
      }

      function onWinTouchEnd() {
        endDrag();
      }

      function onWinMouseMove(e) {
        if (!dragState.active) return;
        onDragMove(e.clientX, e.clientY);
      }

      function onWinMouseUp() {
        endDrag();
      }

      function beginDrag(wrap, index, clientX, clientY) {
        if (dragState.active) return;
        dragState.active = true;
        dragState.listening = true;
        dragState.from = index;
        dragState.current = index;

        var rect = wrap.getBoundingClientRect();
        dragState.offsetX = clientX - rect.left;
        dragState.offsetY = clientY - rect.top;

        var floatEl = document.createElement('img');
        floatEl.className = 'thumb-float';
        floatEl.src = wrap.querySelector('.thumb').src;
        floatEl.style.left = rect.left + 'px';
        floatEl.style.top = rect.top + 'px';
        document.body.appendChild(floatEl);
        dragState.floatEl = floatEl;

        wrap.classList.add('is-placeholder');

        window.addEventListener('touchmove', onWinTouchMove, { capture: true, passive: false });
        window.addEventListener('touchend', onWinTouchEnd, true);
        window.addEventListener('touchcancel', onWinTouchEnd, true);
        window.addEventListener('mousemove', onWinMouseMove, true);
        window.addEventListener('mouseup', onWinMouseUp, true);
      }

      function bindThumbReorder(wrap, index) {
        function clearTimer() {
          if (dragState.timer) {
            clearTimeout(dragState.timer);
            dragState.timer = null;
          }
        }

        function isCloseTarget(target) {
          if (!target) return false;
          if (target.classList && target.classList.contains('thumb-close')) return true;
          return !!(target.closest && target.closest('.thumb-close'));
        }

        function onDown(clientX, clientY) {
          if (dragState.active) return;
          clearTimer();
          dragState.startX = clientX;
          dragState.startY = clientY;
          dragState.timer = setTimeout(function () {
            if (!wrap.parentNode) return;
            var live = Number(wrap.getAttribute('data-index'));
            beginDrag(wrap, isNaN(live) ? index : live, clientX, clientY);
          }, 280);
        }

        wrap.addEventListener('touchstart', function (e) {
          if (e.touches.length !== 1) return;
          if (isCloseTarget(e.target)) return;
          onDown(e.touches[0].clientX, e.touches[0].clientY);
        }, { passive: true });

        wrap.addEventListener('touchmove', function (e) {
          if (dragState.timer && e.touches.length === 1) {
            var t = e.touches[0];
            if (Math.hypot(t.clientX - dragState.startX, t.clientY - dragState.startY) > 8) clearTimer();
          }
        }, { passive: true });

        wrap.addEventListener('touchend', function () {
          if (!dragState.active) clearTimer();
        });
        wrap.addEventListener('touchcancel', function () {
          if (!dragState.active) clearTimer();
        });

        wrap.addEventListener('mousedown', function (e) {
          if (e.button !== 0) return;
          if (isCloseTarget(e.target)) return;
          onDown(e.clientX, e.clientY);
        });
        wrap.addEventListener('mouseup', function () {
          if (!dragState.active) clearTimer();
        });
        wrap.addEventListener('mouseleave', function () {
          if (!dragState.active) clearTimer();
        });
      }

      function removeImageAt(index) {
        state.images.splice(index, 1);
        if (state.cropIndex >= state.images.length) {
          state.cropIndex = Math.max(0, state.images.length - 1);
        }
        if (state.images.length === 0) {
          goUpload();
          return;
        }
        syncCropImage();
        if (state.mode === 'stitch') {
          renderStitchPreview();
          subtitle.textContent = '已选 ' + state.images.length + ' 张，长按可调顺序';
        } else {
          // stay on crop with remaining image
          requestAnimationFrame(function () {
            state.offsetX = 0;
            state.offsetY = 0;
            state.zoomExtra = 0;
            zoomSlider.value = '0';
            resizeCropCanvas();
          });
        }
      }

      function initCropDefaults(keepSettings) {
        if (!keepSettings) {
          state.ratioId = '1:1';
          state.shapeId = 'rect';
          state.gridId = '1';
          state.radiusPct = 20;
          radiusSlider.value = '20';
          radiusLabel.textContent = '20%';
        }
        state.zoomExtra = 0;
        state.offsetX = 0;
        state.offsetY = 0;
        state.displayRotation = 0;
        state.displayFlipX = 1;
        zoomSlider.value = '0';
      }

      function enterWorkspace(imgs, preferMode) {
        state.images = imgs.slice(0, 9);
        state.cropIndex = 0;
        syncCropImage();
        state.stitchGap = 0;
        initCropDefaults(false);
        var mode = preferMode || (imgs.length >= 2 ? 'stitch' : 'crop');
        switchMode(mode, true);
        renderCropChips();
        renderGapChips();
      }

      function enterCrop(img) {
        enterWorkspace([img], 'crop');
      }

      function enterStitch(imgs) {
        enterWorkspace(imgs, 'stitch');
      }

      function onFilesSelected(files, append) {
        if (!files || !files.length) return;
        var entryMode = pendingEntryMode;
        var list = Array.prototype.slice.call(files);
        var pickedExtra = 0;
        if (list.length > MAX_PICK) {
          pickedExtra = list.length - MAX_PICK;
          list = list.slice(0, MAX_PICK);
        }

        showLoading(append ? '添加中…' : '处理中…');

        // 让 loading 先上屏，再做分类/解码
        requestAnimationFrame(function () {
          setTimeout(function () {
            var videoCount = 0;
            var unknownCount = 0;
            var imagesOnly = [];
            var i;
            for (i = 0; i < list.length; i++) {
              var kind = classifyFileSync(list[i]);
              if (kind === 'video') videoCount += 1;
              else if (kind === 'image') imagesOnly.push(list[i]);
              else unknownCount += 1;
            }

            function finishTips() {
              if (videoCount > 0) {
                showToast(videoCount === 1
                  ? '不支持视频，已忽略所选视频'
                  : ('不支持视频，已忽略 ' + videoCount + ' 个视频'));
              } else if (pickedExtra > 0) {
                showToast('最多选择 ' + MAX_PICK + ' 张，已自动取前 ' + MAX_PICK + ' 张');
              } else if (!imagesOnly.length && unknownCount > 0) {
                showToast('请选择图片（不支持视频）');
              }
            }

            if (!imagesOnly.length) {
              hideLoading();
              finishTips();
              if (!videoCount && !unknownCount) showToast('请选择图片');
              fileInputMulti.value = '';
              return;
            }

            var room = append ? (MAX_PICK - state.images.length) : MAX_PICK;
            if (room <= 0) {
              hideLoading();
              showToast('最多选择 ' + MAX_PICK + ' 张图片');
              fileInputMulti.value = '';
              return;
            }
            imagesOnly = imagesOnly.slice(0, room);

            Promise.all(imagesOnly.map(function (file) {
              return loadImage(file).then(function (img) {
                return img;
              }, function () {
                return null;
              });
            })).then(function (imgs) {
              imgs = imgs.filter(Boolean);
              hideLoading();
              finishTips();

              if (!imgs.length) {
                showToast('无法读取图片，请检查相册权限后重试');
                fileInputMulti.value = '';
                return;
              }

              if (append) {
                state.images = state.images.concat(imgs).slice(0, MAX_PICK);
                syncCropImage();
                if (state.mode === 'stitch') {
                  renderStitchPreview();
                  subtitle.textContent = state.images.length < 2
                    ? '已带入裁图图片，可继续添加至 2～9 张'
                    : ('已选 ' + state.images.length + ' 张，长按可调顺序');
                }
                fileInputAdd.value = '';
                return;
              }

              var prefer = entryMode || (
                state.mode === 'crop' || state.mode === 'stitch'
                  ? state.mode
                  : (imgs.length >= 2 ? 'stitch' : 'crop')
              );
              pendingEntryMode = null;
              fileInputMulti.value = '';
              enterWorkspace(imgs, prefer);
            }).catch(function () {
              hideLoading();
              showToast('处理失败，请重试');
              fileInputMulti.value = '';
            });
          }, 0);
        });
      }

      function buildStitchDataUrl() {
        if (state.images.length < 2) return null;
        var targetW = 1080;
        var gap = state.stitchGap;
        var heights = [];
        var totalH = 0;
        var i;
        for (i = 0; i < state.images.length; i++) {
          var img = state.images[i];
          var h = Math.round(img.naturalHeight * (targetW / img.naturalWidth));
          heights.push(h);
          totalH += h;
          if (i < state.images.length - 1) totalH += gap;
        }

        var maxH = 8000;
        var scale = totalH > maxH ? maxH / totalH : 1;
        var outW = Math.round(targetW * scale);
        var outH = Math.round(totalH * scale);
        var gapOut = Math.round(gap * scale);

        workCanvas.width = outW;
        workCanvas.height = outH;
        workCtx.fillStyle = '#fff';
        workCtx.fillRect(0, 0, outW, outH);

        var y = 0;
        for (i = 0; i < state.images.length; i++) {
          var ih = Math.round(heights[i] * scale);
          workCtx.drawImage(state.images[i], 0, y, outW, ih);
          y += ih;
          if (i < state.images.length - 1) y += gapOut;
        }
        return workCanvas.toDataURL('image/jpeg', 0.92);
      }

      function processStitch() {
        var dataUrl = buildStitchDataUrl();
        if (!dataUrl) {
          showToast('拼图请选择 2～9 张图片');
          return;
        }
        state.results = [{ dataUrl: dataUrl, num: null }];
        renderResults();
      }

      function stitchSaveDirect() {
        var dataUrl = buildStitchDataUrl();
        if (!dataUrl) {
          showToast('拼图请选择 2～9 张图片');
          return;
        }
        state.mode = 'stitch';
        state.results = [{ dataUrl: dataUrl, num: null }];
        saveAll(btnStitchSave);
      }

      function openReselect() {
        pendingEntryMode = state.mode === 'stitch' ? 'stitch' : 'crop';
        fileInputMulti.value = '';
        fileInputMulti.click();
      }

      function renderResults() {
        var grid = state.mode === 'crop' ? getGrid() : { cols: 1, rows: 1 };
        var colsClass = 'cols-' + Math.min(3, Math.max(1, grid.cols));
        if (grid.cols === 1) colsClass = 'cols-1';
        resultGrid.className = 'result-grid ' + colsClass;
        resultGrid.innerHTML = '';

        var rc = state.mode === 'crop' ? ratioClass() : 'ratio-auto';
        var roundedStyle = '';
        if (state.mode === 'crop' && state.shapeId === 'round' && state.gridId === '1') {
          roundedStyle = 'border-radius:' + state.radiusPct + '%';
        }

        var cellAspect = null;
        if (state.mode === 'crop' && grid.cols * grid.rows > 1) {
          cellAspect = getRatio() * (grid.rows / grid.cols);
        }

        state.results.forEach(function (item) {
          var cell = document.createElement('div');
          var cls = 'result-cell';
          if (state.mode === 'crop' && state.shapeId === 'circle' && state.gridId === '1') cls += ' circle';
          else if (state.mode === 'crop' && state.shapeId === 'round' && state.gridId === '1') cls += ' rounded';
          if (rc && !(state.mode === 'crop' && state.shapeId === 'circle')) cls += ' ' + rc;
          cell.className = cls;
          if (roundedStyle) cell.setAttribute('style', roundedStyle);
          if (cellAspect != null) cell.style.aspectRatio = String(cellAspect);
          var img = document.createElement('img');
          img.src = item.dataUrl;
          img.alt = item.num ? '第' + item.num + '格' : '结果';
          img.draggable = false;
          cell.appendChild(img);
          if (item.num) {
            var num = document.createElement('span');
            num.className = 'num';
            num.textContent = String(item.num);
            cell.appendChild(num);
          }
          resultGrid.appendChild(cell);
        });

        if (state.mode === 'stitch') {
          resultHint.textContent = '长图已生成，可保存到相册';
        } else if (state.results.length === 1) {
          resultHint.textContent = isShapedExport()
            ? '已导出透明底 PNG，可保存到相册'
            : '可保存到相册';
        } else {
          resultHint.textContent = '共 ' + state.results.length + ' 张，按 1→' + state.results.length + ' 顺序保存后可拼大图';
        }
        showScreen('result');
      }

      function bakeTransform(mode, done) {
        if (!state.image || state.animating) return;
        state.animating = true;
        var fromRot = 0;
        var toRot = mode === 'rotate' ? Math.PI / 2 : 0;
        var fromFlip = 1;
        var toFlip = mode === 'flip' ? -1 : 1;

        var start = performance.now();
        var duration = 280;
        function frame(now) {
          var t = Math.min(1, (now - start) / duration);
          var e = easeOutCubic(t);
          state.displayRotation = fromRot + (toRot - fromRot) * e;
          state.displayFlipX = fromFlip + (toFlip - fromFlip) * e;
          drawCrop();
          if (t < 1) {
            requestAnimationFrame(frame);
          } else {
            // bake into new image
            var src = state.image;
            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');
            if (mode === 'rotate') {
              canvas.width = src.naturalHeight;
              canvas.height = src.naturalWidth;
              ctx.translate(canvas.width / 2, canvas.height / 2);
              ctx.rotate(Math.PI / 2);
              ctx.drawImage(src, -src.naturalWidth / 2, -src.naturalHeight / 2);
            } else {
              canvas.width = src.naturalWidth;
              canvas.height = src.naturalHeight;
              ctx.translate(canvas.width, 0);
              ctx.scale(-1, 1);
              ctx.drawImage(src, 0, 0);
            }
            var img = new Image();
            img.onload = function () {
              state.image = img;
              if (state.images.length) {
                state.images[state.cropIndex] = img;
              }
              state.displayRotation = 0;
              state.displayFlipX = 1;
              state.offsetX = 0;
              state.offsetY = 0;
              state.zoomExtra = 0;
              zoomSlider.value = '0';
              computeTargetCropSize();
              setCenteredCrop(state.targetCropW, state.targetCropH);
              computeMinScale();
              state.animating = false;
              drawCrop();
              if (done) done();
            };
            img.src = canvas.toDataURL('image/png');
          }
        }
        requestAnimationFrame(frame);
      }

      function isPermissionError(err) {
        var msg = '';
        if (!err) return false;
        if (typeof err === 'string') msg = err;
        else if (err.errMsg) msg = String(err.errMsg);
        else if (err.message) msg = String(err.message);
        else msg = String(err);
        msg = msg.toLowerCase();
        return msg.indexOf('auth') >= 0 ||
          msg.indexOf('permission') >= 0 ||
          msg.indexOf('denied') >= 0 ||
          msg.indexOf('权限') >= 0 ||
          msg.indexOf('相册') >= 0;
      }

      function saveOne(dataUrl) {
        return window.xhs.miniTool.writeTempFile({ data: dataUrl }).then(function (res) {
          return window.xhs.miniTool.saveImageToPhotosAlbum({ filePath: res.filePath });
        });
      }

      function saveAll(triggerBtn) {
        if (!state.results.length || state.saving) return;
        if (!hasXhs()) {
          alert('请在小红书 App 内使用「存相册」');
          return;
        }

        var btn = triggerBtn || btnSave;
        state.saving = true;
        btn.disabled = true;
        var oldText = btn.textContent;
        btn.textContent = '保存中…';

        var i = 0;
        var ok = 0;

        function finish(msg) {
          state.saving = false;
          btn.disabled = false;
          btn.textContent = oldText;
          alert(msg);
        }

        function next() {
          if (i >= state.results.length) {
            finish('已保存 ' + ok + ' 张到相册');
            return;
          }
          var data = state.results[i].dataUrl;
          i += 1;
          saveOne(data).then(function () {
            ok += 1;
            next();
          }).catch(function (err) {
            if (isPermissionError(err)) {
              finish(ok > 0
                ? ('已保存 ' + ok + '/' + state.results.length + ' 张。' + PERM_TIP)
                : PERM_TIP);
            } else {
              finish(ok > 0
                ? ('已保存 ' + ok + '/' + state.results.length + ' 张，剩余失败请重试')
                : '保存失败，请检查相册权限后重试');
            }
          });
        }

        next();
      }

      // events
      document.querySelectorAll('.tool-card').forEach(function (card) {
        card.addEventListener('click', function () {
          openEntryPicker(card.getAttribute('data-mode'));
        });
      });

      document.querySelectorAll('.btn-mode-switch').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var target = btn.getAttribute('data-target');
          if (target === 'crop' || target === 'stitch') switchMode(target);
        });
      });

      if (btnGridColor) {
        btnGridColor.addEventListener('click', function (e) {
          e.stopPropagation();
          toggleGridColorPop();
        });
      }
      document.addEventListener('click', function () {
        closeGridColorPop();
      });
      if (gridColorPop) {
        gridColorPop.addEventListener('click', function (e) {
          e.stopPropagation();
        });
      }
      renderGridColorPop();

      document.getElementById('btn-reselect').addEventListener('click', openReselect);
      document.getElementById('btn-stitch-reselect').addEventListener('click', openReselect);
      document.getElementById('btn-process').addEventListener('click', processCrop);
      btnStitchSave.addEventListener('click', stitchSaveDirect);
      document.getElementById('btn-back-edit').addEventListener('click', function () {
        if (state.mode === 'crop') {
          showScreen('edit');
          requestAnimationFrame(resizeCropCanvas);
        } else {
          showScreen('stitch');
        }
      });
      btnSave.addEventListener('click', function () { saveAll(btnSave); });
      document.getElementById('btn-rotate').addEventListener('click', function () { bakeTransform('rotate'); });
      document.getElementById('btn-flip').addEventListener('click', function () { bakeTransform('flip'); });

      fileInputMulti.addEventListener('change', function () {
        if (fileInputMulti.files && fileInputMulti.files.length) {
          onFilesSelected(fileInputMulti.files, false);
        }
      });

      fileInputAdd.addEventListener('change', function () {
        if (fileInputAdd.files && fileInputAdd.files.length) {
          onFilesSelected(fileInputAdd.files, true);
          fileInputAdd.value = '';
        }
      });

      zoomSlider.addEventListener('input', function () {
        // live preview while dragging
        state.zoomExtra = Number(zoomSlider.value);
        computeMinScale();
        clampOffset();
        drawCrop();
      });
      zoomSlider.addEventListener('change', function () {
        // settle animation feels smoother after release
        var targetExtra = Number(zoomSlider.value);
        var fromScale = state.scale;
        computeTargetCropSize();
        var minS = Math.max(state.cropW / state.image.naturalWidth, state.cropH / state.image.naturalHeight);
        var toScale = minS * (1 + targetExtra / 100);
        var start = performance.now();
        function frame(now) {
          var t = Math.min(1, (now - start) / 200);
          var e = easeOutCubic(t);
          state.scale = fromScale + (toScale - fromScale) * e;
          state.zoomExtra = (state.scale / minS - 1) * 100;
          state.minScale = minS;
          clampOffset();
          drawCrop();
          if (t < 1) requestAnimationFrame(frame);
          else {
            state.zoomExtra = targetExtra;
            state.scale = toScale;
            clampOffset();
            drawCrop();
          }
        }
        requestAnimationFrame(frame);
      });

      radiusSlider.addEventListener('input', function () {
        state.radiusPct = Number(radiusSlider.value);
        radiusLabel.textContent = radiusSlider.value + '%';
        drawCrop();
      });

      function toLocal(clientX, clientY) {
        var rect = cropViewport.getBoundingClientRect();
        return { x: clientX - rect.left, y: clientY - rect.top };
      }

      function hitResizeHandle(x, y) {
        if (state.ratioId !== 'free' || state.shapeId !== 'rect') return null;
        var c = getCropRect();
        var t = 18;
        var nearL = Math.abs(x - c.left) <= t;
        var nearR = Math.abs(x - (c.left + c.width)) <= t;
        var nearT = Math.abs(y - c.top) <= t;
        var nearB = Math.abs(y - (c.top + c.height)) <= t;
        if (nearT && nearL) return 'nw';
        if (nearT && nearR) return 'ne';
        if (nearB && nearL) return 'sw';
        if (nearB && nearR) return 'se';
        if (nearT && x >= c.left && x <= c.left + c.width) return 'n';
        if (nearB && x >= c.left && x <= c.left + c.width) return 's';
        if (nearL && y >= c.top && y <= c.top + c.height) return 'w';
        if (nearR && y >= c.top && y <= c.top + c.height) return 'e';
        return null;
      }

      function resizeByHandle(handle, x, y) {
        var left = state.cropX;
        var top = state.cropY;
        var right = left + state.cropW;
        var bottom = top + state.cropH;
        if (handle.indexOf('n') >= 0) top = y;
        if (handle.indexOf('s') >= 0) bottom = y;
        if (handle.indexOf('w') >= 0) left = x;
        if (handle.indexOf('e') >= 0) right = x;
        if (right < left) {
          var tx = left; left = right; right = tx;
        }
        if (bottom < top) {
          var ty = top; top = bottom; bottom = ty;
        }
        setCropRect(left, top, right - left, bottom - top);
        computeMinScale();
        if (state.scale < state.minScale) {
          state.scale = state.minScale;
          state.zoomExtra = 0;
          zoomSlider.value = '0';
        }
        clampOffset();
      }

      function stopCropInertia() {
        if (state.inertiaRaf) {
          cancelAnimationFrame(state.inertiaRaf);
          state.inertiaRaf = 0;
        }
        state.velX = 0;
        state.velY = 0;
      }

      function startCropInertia() {
        stopCropInertia();
        var speed = Math.hypot(state.velX, state.velY);
        if (speed < 0.35 || state.dragMode === 'resize') {
          state.velX = 0;
          state.velY = 0;
          return;
        }
        // 限制初速，手感更接近 iOS
        var maxV = 42;
        if (speed > maxV) {
          var s = maxV / speed;
          state.velX *= s;
          state.velY *= s;
        }
        var friction = 0.95;
        function tick() {
          state.offsetX += state.velX;
          state.offsetY += state.velY;
          clampOffset();
          drawCrop();
          state.velX *= friction;
          state.velY *= friction;
          if (Math.hypot(state.velX, state.velY) < 0.18) {
            state.inertiaRaf = 0;
            state.velX = 0;
            state.velY = 0;
            return;
          }
          state.inertiaRaf = requestAnimationFrame(tick);
        }
        state.inertiaRaf = requestAnimationFrame(tick);
      }

      function onPointerDown(clientX, clientY) {
        if (state.animating) return;
        stopCropInertia();
        var local = toLocal(clientX, clientY);
        state.lastX = clientX;
        state.lastY = clientY;
        state.lastMoveT = performance.now();
        state.velX = 0;
        state.velY = 0;
        state.resizeHandle = hitResizeHandle(local.x, local.y);
        state.dragMode = state.resizeHandle ? 'resize' : 'pan';
        state.dragging = true;
      }

      function onPointerMove(clientX, clientY) {
        if (!state.dragging) return;
        if (state.dragMode === 'resize' && state.resizeHandle) {
          var local = toLocal(clientX, clientY);
          resizeByHandle(state.resizeHandle, local.x, local.y);
          state.lastX = clientX;
          state.lastY = clientY;
          state.lastMoveT = performance.now();
          drawCrop();
          return;
        }
        var now = performance.now();
        var dt = Math.max(8, now - (state.lastMoveT || now));
        var dx = clientX - state.lastX;
        var dy = clientY - state.lastY;
        state.offsetX += dx;
        state.offsetY += dy;
        // 指数平滑速度（px / 16ms）
        var vx = dx / dt * 16;
        var vy = dy / dt * 16;
        state.velX = state.velX * 0.6 + vx * 0.4;
        state.velY = state.velY * 0.6 + vy * 0.4;
        state.lastX = clientX;
        state.lastY = clientY;
        state.lastMoveT = now;
        clampOffset();
        drawCrop();
      }

      function onPointerUp() {
        var wasPan = state.dragging && state.dragMode === 'pan';
        state.dragging = false;
        state.dragMode = 'pan';
        state.resizeHandle = null;
        if (wasPan) startCropInertia();
      }

      // 拼图预览：自管滚动 + 惯性（避免部分 WebView 无 fling / 与原生双重惯性）
      var stitchInertia = {
        active: false,
        lastY: 0,
        lastT: 0,
        vel: 0,
        raf: 0,
        scrollY: 0
      };

      function stitchMaxScroll() {
        return Math.max(0, stitchPreview.scrollHeight - stitchPreview.clientHeight);
      }

      function setStitchScroll(y) {
        var max = stitchMaxScroll();
        stitchInertia.scrollY = Math.max(0, Math.min(max, y));
        stitchPreview.scrollTop = stitchInertia.scrollY;
      }

      function stopStitchInertia() {
        if (stitchInertia.raf) {
          cancelAnimationFrame(stitchInertia.raf);
          stitchInertia.raf = 0;
        }
        stitchInertia.vel = 0;
        stitchInertia.active = false;
      }

      function startStitchInertia() {
        var speed = Math.abs(stitchInertia.vel);
        if (speed < 0.4) {
          stitchInertia.vel = 0;
          return;
        }
        var maxV = 48;
        if (speed > maxV) stitchInertia.vel = (stitchInertia.vel > 0 ? 1 : -1) * maxV;
        var friction = 0.955;
        function tick() {
          setStitchScroll(stitchInertia.scrollY + stitchInertia.vel);
          stitchInertia.vel *= friction;
          if (stitchInertia.scrollY <= 0 || stitchInertia.scrollY >= stitchMaxScroll()) {
            stitchInertia.vel = 0;
          }
          if (Math.abs(stitchInertia.vel) < 0.2) {
            stitchInertia.raf = 0;
            stitchInertia.vel = 0;
            return;
          }
          stitchInertia.raf = requestAnimationFrame(tick);
        }
        stitchInertia.raf = requestAnimationFrame(tick);
      }

      stitchPreview.addEventListener('touchstart', function (e) {
        stopStitchInertia();
        if (e.touches.length !== 1) return;
        stitchInertia.active = true;
        stitchInertia.lastY = e.touches[0].clientY;
        stitchInertia.lastT = performance.now();
        stitchInertia.vel = 0;
        stitchInertia.scrollY = stitchPreview.scrollTop;
      }, { passive: true });

      stitchPreview.addEventListener('touchmove', function (e) {
        if (!stitchInertia.active || e.touches.length !== 1) return;
        e.preventDefault();
        var now = performance.now();
        var y = e.touches[0].clientY;
        var dt = Math.max(8, now - stitchInertia.lastT);
        var dy = stitchInertia.lastY - y;
        setStitchScroll(stitchInertia.scrollY + dy);
        stitchInertia.vel = stitchInertia.vel * 0.55 + (dy / dt * 16) * 0.45;
        stitchInertia.lastY = y;
        stitchInertia.lastT = now;
      }, { passive: false });

      stitchPreview.addEventListener('touchend', function () {
        if (!stitchInertia.active) return;
        stitchInertia.active = false;
        startStitchInertia();
      }, { passive: true });

      stitchPreview.addEventListener('touchcancel', function () {
        stitchInertia.active = false;
        stopStitchInertia();
      }, { passive: true });

      // 桌面端拼图预览也可拖
      stitchPreview.addEventListener('mousedown', function (e) {
        if (e.button !== 0) return;
        stopStitchInertia();
        stitchInertia.active = true;
        stitchInertia.lastY = e.clientY;
        stitchInertia.lastT = performance.now();
        stitchInertia.vel = 0;
        stitchInertia.scrollY = stitchPreview.scrollTop;
      });
      window.addEventListener('mousemove', function (e) {
        if (!stitchInertia.active || !screens.stitch.classList.contains('active')) return;
        if (e.buttons !== 1) return;
        var now = performance.now();
        var dt = Math.max(8, now - stitchInertia.lastT);
        var dy = stitchInertia.lastY - e.clientY;
        setStitchScroll(stitchInertia.scrollY + dy);
        stitchInertia.vel = stitchInertia.vel * 0.55 + (dy / dt * 16) * 0.45;
        stitchInertia.lastY = e.clientY;
        stitchInertia.lastT = now;
      });
      window.addEventListener('mouseup', function () {
        if (!stitchInertia.active || !screens.stitch.classList.contains('active')) return;
        // 仅当拼图预览在拖（非裁图拖拽）
        if (state.dragging) return;
        stitchInertia.active = false;
        startStitchInertia();
      });

      cropViewport.addEventListener('mousedown', function (e) {
        e.preventDefault();
        onPointerDown(e.clientX, e.clientY);
      });
      window.addEventListener('mousemove', function (e) { onPointerMove(e.clientX, e.clientY); });
      window.addEventListener('mouseup', onPointerUp);

      cropViewport.addEventListener('touchstart', function (e) {
        if (e.touches.length === 1) onPointerDown(e.touches[0].clientX, e.touches[0].clientY);
        else if (e.touches.length === 2) {
          stopCropInertia();
          state.dragging = false;
          state.dragMode = 'pan';
          state.resizeHandle = null;
          var dx = e.touches[0].clientX - e.touches[1].clientX;
          var dy = e.touches[0].clientY - e.touches[1].clientY;
          state.pinchStartDist = Math.hypot(dx, dy);
          state.pinchStartScale = state.scale;
          state.pinchStartZoom = state.zoomExtra;
        }
      }, { passive: true });

      cropViewport.addEventListener('touchmove', function (e) {
        if (e.touches.length === 1 && state.dragging) {
          e.preventDefault();
          onPointerMove(e.touches[0].clientX, e.touches[0].clientY);
        } else if (e.touches.length === 2) {
          e.preventDefault();
          stopCropInertia();
          var dx = e.touches[0].clientX - e.touches[1].clientX;
          var dy = e.touches[0].clientY - e.touches[1].clientY;
          var dist = Math.hypot(dx, dy);
          if (state.pinchStartDist > 0) {
            var ratio = dist / state.pinchStartDist;
            var nextScale = Math.max(state.minScale, Math.min(state.minScale * 4, state.pinchStartScale * ratio));
            state.scale = nextScale;
            state.zoomExtra = Math.max(0, Math.min(300, (nextScale / state.minScale - 1) * 100));
            zoomSlider.value = String(Math.round(state.zoomExtra));
            clampOffset();
            drawCrop();
          }
        }
      }, { passive: false });

      cropViewport.addEventListener('touchend', onPointerUp);

      window.addEventListener('resize', function () {
        if (screens.edit.classList.contains('active')) resizeCropCanvas();
      });

      var lastTouchEnd = 0;
      document.addEventListener('touchend', function (e) {
        var now = Date.now();
        if (now - lastTouchEnd < 300) e.preventDefault();
        lastTouchEnd = now;
      }, { passive: false });
    })();
